# Third-party components — GrainBrick beta 1.0.1 (native Python module version)

- GrainBrick proprietary Python code is provided ONLY as a Nuitka compiled ARM64 CPython extension.
- Pygame remains an EXTERNAL KNULLI system package; it is NOT bundled in this release.
  Pygame is LGPL licensed; the application does not include compiled Pygame modules.
- NumPy 1.26.4 (CPython 3.12 ARM64 manylinux2014 binary wheel) IS bundled unmodified
  under `_vendor/` with its upstream license, metadata, bundled shared libraries,
  and notices. NumPy is BSD-3-Clause licensed; bundled native dependencies have
  their own license terms (see `_vendor/numpy-1.26.4.dist-info/LICENSE.txt`).
  GrainBrick never installs or changes KNULLI's system NumPy.
- The library `libSoundTouch.so.1` IS redistributed and is LGPL-2.1 licensed.
  Its matching original sources, distro patches and the MIT bridge source are included
  in `THIRD_PARTY_SOURCES/SoundTouch_Compliance_Sources.zip`.
- `libgrainbrick_soundtouch.so` is a separate MIT-licensed bridge that dynamically
  links `libSoundTouch.so.1` with $ORIGIN RUNPATH.
- Nuitka compiler runtime license exception applies to compiler-generated target
  libraries; see https://github.com/Nuitka/Nuitka/blob/develop/LICENSE-RUNTIME.txt
  and https://nuitka.net/user-documentation/use-cases.html
- No GrainBrick proprietary `.py`, generated C or object build tree is included.

GrainBrick permits reverse engineering for the limited purpose of debugging
modifications to LGPL-covered components, and permits modifications of the
combined application for the user's own private use, insofar as LGPL 2.1 §6 requires.
This notice does not grant ownership of the proprietary GrainBrick implementation.

Each new release candidate must be tested on a real TrimUI Brick before publishing.
Technical checks are not a substitute for professional legal review.

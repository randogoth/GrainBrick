# GrainBrick beta 1.0.1 — Universal KNULLI ARM64

Free beta. GrainBrick application modules are compiled with Nuitka --mode=module
for ARM64 CPython 3.12; no proprietary Python implementation is bundled.
External KNULLI Python 3.12 and system Pygame are required. NumPy 1.26.4 ARM64
is bundled under _vendor, with third-party notices and licenses.

INSTALL: Extract the ZIP into `/userdata/roms/ports/`.
You will see a directory `grainbrick beta 1.0.1` and a PORTS launcher
`GrainBrick beta 1.0.1.sh` beside it. Refresh Ports and start the launcher.
The app folder contains demo-samples/ and demo-projects/; these are copied to
samples/ and projects/ on first run without overwriting existing user data.

Confirmed hardware during source-level testing: original TrimUI Brick (KNULLI)
and Anbernic RG40XXV (KNULLI). Binary 1.0.1 must be tested on both devices
before publication. TrimUI Smart Pro remains unverified; compatibility is
not guaranteed.

This beta includes adaptive display and input, USB ALSA recording, USB output
and volume buttons for USB devices with a suitable ALSA mixer.
It does NOT include the separate experimental LIVE development update.

See THIRD_PARTY_NOTICES.md for component licenses and SoundTouch relinking
information. Logs: `grainbrick beta 1.0.1/gb_launch.log`.

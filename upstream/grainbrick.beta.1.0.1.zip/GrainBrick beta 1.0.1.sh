#!/bin/sh
# GrainBrick 1.0.1 universal beta for KNULLI AArch64.
set -u
APP='/userdata/roms/ports/grainbrick beta 1.0.1'
LOG="$APP/gb_launch.log"
cd "$APP" || exit 1
mkdir -p "$APP/samples" "$APP/projects" "$APP/recordings" || exit 1
for wav in "$APP"/demo-samples/*.wav; do
  [ -f "$wav" ] || continue
  name=${wav##*/}
  if [ ! -e "$APP/samples/$name" ] && [ ! -L "$APP/samples/$name" ]; then
    cp "$wav" "$APP/samples/$name" || exit 1
  fi
done
if [ -f "$APP/demo-projects/AMBIENT.json" ] && [ ! -e "$APP/projects/AMBIENT.json" ] && [ ! -L "$APP/projects/AMBIENT.json" ]; then
  cp "$APP/demo-projects/AMBIENT.json" "$APP/projects/AMBIENT.json" || exit 1
fi
export GRAINBRICK_ROOT="$APP"
export GRAINBRICK_DISPLAY_FILTER=smooth
export PYTHONUNBUFFERED=1
printf '
=== GrainBrick universal 1.0.1 native module ===
' >> "$LOG"
python3 -B "$APP/gb_launch.py" >> "$LOG" 2>&1
result=$?
printf 'GrainBrick exit: %s
' "$result" >> "$LOG"
exit "$result"
